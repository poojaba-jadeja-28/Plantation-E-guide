# Plantation_Guide
this is our first mobile application with android &amp; java. we are ceating the plantation guide for plants.
